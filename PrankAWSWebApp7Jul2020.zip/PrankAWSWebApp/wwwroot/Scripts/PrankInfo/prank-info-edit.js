﻿function prankChangeImage() {
    $('#dvPrankImageView').hide();
    $('#divPrankInfoImageArea').show();

}

function prankChangePreviewAudioFile() {
    $('#dvPreviewAudioView').hide();
    $('#divPreviewAudioArea').show();
}

function prankChangeMainAudioFile() {
    $('#dvMainAudioView').hide();
    $('#divMainAudioArea').show();
}