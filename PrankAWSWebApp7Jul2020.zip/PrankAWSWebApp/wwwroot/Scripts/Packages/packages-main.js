﻿
$(document).ready(function () {
    DataTableInit();
});

$("#btnAddPackage").click(function (e) {
    $.ajax({
        url: '/Admin/Package/PartialCreate',
        type: 'GET',
        async: false,
        beforeSend: function () {

        },
        success: function (data) {
            if (data != null) {
                $('#dvaddPackage').html('');
                $('#dvaddPackage').html(data.html);
                $("#myPackageModal").modal("show");
                $('#packageHeading').text("Add Package");
            }
        },
        error: function () {
            alert("Error");
            //$(".ajax-loading-block-window").hide();
            //$(".showalertMessage").html("Technical error occured, please contact to administrator.");
            //$('.divWarningMessageBox').show();
            //setTimeout(function () {
            //    $('.divWarningMessageBox').fadeOut('slow');
            //}, 3000);
        },
        complete: function (jqXHR, status) {
            //setTimeout(function () {
            //    $(".ajax-loading-block-window").hide();
            //}, 500);
            //console.log("CreateQuotationDetail complete:-");
        }
    });
})

$("#btnSave").click(function (e) {
    e.preventDefault();
    $('#lblusererror').hide();
    var form = "frmpackage";
    var token = $('input[name="__RequestVerificationToken"]').val();
    var headers = {};
    headers['__RequestVerificationToken'] = token;
    if ($("#" + form).valid()) {
        $(".loadingBox").show();
        $.ajax({
            url: $("#" + form).attr("action"),
            type: $("#" + form).attr("method"),
            data: $("#" + form).serialize(),
            dataType: "json",
            headers: headers,
            success: function (data) {
                //alert(data.statusCode+"   length-:" + data.objResponse.length + "      " + data.objResponse.StatusCode + "      " + data.objResponse.html);
                if (data.objResponse.statusCode === 200) {
                    //if (data.objResponse.html !== "") {
                    //    $('#tbodyPackages').empty();
                    //    $('#tbodyPackages').append(data.objResponse.html);
                    //    $("#myPackageModal").modal("hide");
                    //}
                    $("#myPackageModal").modal("hide");
                    DataTableInit();
                    toastr.success(data.objResponse.message);
                }
                else {
                    toastr.error(data.objResponse.message);
                }

            },
            error: function (xhr, status, error) {
                //  toastr.error("Oops something went wrong");
                alert('err' + xhr.responseText);
            },
            beforeSend: function () {
                $(".loadingBox").show();
            },
            complete: function () {
                $(".loadingBox").hide();
            }
        });
    }
    else {
        toastr.error("Oops something went wrong");
    }
})

$(document).on("click", ".btnEdit", function (e) {
    var tr = $(this).closest("tr");
    //var id = tr.attr("data-id");
    var id = tr.find(".hidid").val();
    $.ajax({
        url: '/Admin/Package/PartialEdit',
        type: 'GET',
        async: false,
        data: { id: id },
        success: function (data) {
            if (data != null) {
                $('#dvaddPackage').empty();
                $('#dvaddPackage').append(data.html);
                $("#myPackageModal").modal("show");
                $('#packageHeading').text("Edit Package");
            }
        },
        error: function () {
            alert("Error");

        },
        complete: function (jqXHR, status) {
        }
    });
});

$(document).on("click", ".btnDelete", function (e) {
    var tr = $(this).closest("tr");
    var id = tr.find(".hidid").val();// tr.attr("data-id");
    
    var r = confirm("Do you want to delete !");
    if (r == true) {
        $.ajax({
            url: '/Admin/Package/Delete',
            type: 'GET',
            async: false,
            data: { id: id },
            beforeSend: function () {
                $(".loadingBox").show();
            },
            success: function (data) {
                if (data != null) {
                    if (data.objResponse.statusCode === 200) {
                        toastr.success(data.objResponse.message);
                        DataTableInit();
                    }
                    else {
                        toastr.error(data.objResponse.message);
                    }
                }
            },
            error: function (jqXHR, status) {
                alert("Error" + jqXHR.responseText);
                $(".loadingBox").hide();
            },
            complete: function (jqXHR, status) {
                $(".loadingBox").hide();
            }
        });
    } else {

    }
});

function DataTableInit() {
   
    var tablePackage = $("#dataTablePackageinfo").DataTable({
        iDisplayLength: 10,
        responsive: true,
        //stateSave: true,
        columns: [
            {
                "bSearchable": false,
                "bSortable": true,
                'render': function (data, type, full, meta) {
                    return full.packageTitle;
                }
            },
            {
                "bSearchable": false,
                "bSortable": true,
                'render': function (data, type, full, meta) {
                    return full.tokenCreditsPoint;
                }
            }, {
                "bSearchable": false,
                "bSortable": true,
                'render': function (data, type, full, meta) {
                    return full.packagePrice;
                }
            },
            {
                "bSearchable": false,
                "bSortable": false,
                'render': function (data, type, full, meta) {
                    var edit = '<button class="btn btn-light border btnEdit">Edit</button>&nbsp;';
                    var _delete = '<button class="btn btn-danger btnDelete">Delete</button >';
                    var id = '<input type="hidden" value=' + full.packageId + ' class="hidid"/>';
                    return edit + _delete +id;
                }
            }

        ],
        destroy: true,
        oLanguage: {
            sProcessing: "<img src='/Images/Loader.gif'  style='width:32px;height:32px;'> &nbsp;&nbsp; Processing......"
        },
        processing: true,
        bServerSide: true,
        sAjaxSource: '/Admin/Package/PartialGetPackages',
        sServerMethod: 'post',
        searching: false,
        "fnDrawCallback": function (oSettings) {

            //alert(oSettings.json + "    " + JSON.stringify(oSettings));
        },
        "fnServerParams": function (aoData) {
            // aoData.push({ "name": "sSearch", "value": $("#txtSearch").val() });
        }
        //"scrollY": "200px",
    });
}