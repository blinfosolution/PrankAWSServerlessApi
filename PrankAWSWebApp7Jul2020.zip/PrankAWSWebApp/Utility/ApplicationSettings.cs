﻿namespace PrankAWSWebApp.Utility
{
    public class ApplicationSettings
    {
        public static string WebApiUrl { get; set; }
    }
}
