﻿namespace PrankAWSWebApp.Common
{
    public class SaveResponse
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public string Html { get; set; }
    }
}
