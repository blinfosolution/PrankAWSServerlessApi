﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrankAWSWebApp.AwsS3
{
    public class AwsS3BucketOptions
    {
        public string BucketName { get; set; }
    }
}
