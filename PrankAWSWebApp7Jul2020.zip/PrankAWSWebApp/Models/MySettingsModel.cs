﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrankAWSWebApp.Models
{
    public class MySettingsModel
    {
        public string WebApiBaseUrl { get; set; }
    }
}
